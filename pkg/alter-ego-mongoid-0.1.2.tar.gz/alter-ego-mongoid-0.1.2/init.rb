require 'alter_ego/mongoid_adapter'
